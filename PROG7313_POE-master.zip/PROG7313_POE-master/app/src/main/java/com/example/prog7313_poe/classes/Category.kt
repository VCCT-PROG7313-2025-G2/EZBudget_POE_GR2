package com.example.prog7313_poe.classes

data class Category(
    var categoryID : String = "",
    var categoryName: String = "",
    var userID : String = "",
){
    constructor(): this("","","")
}


