package com.example.prog7313_poe.ui.loginRegister

import androidx.fragment.app.Fragment

class RegisterFragment : Fragment(){
    // TODO: Use the ViewModel
}