package com.example.prog7313_poe.classes

class CategorySpending (
    var categoryName: String,
    var totalAmount: Double
)