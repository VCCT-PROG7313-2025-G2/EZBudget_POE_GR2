package com.example.prog7313_poe.classes

data class RankThreshold(
    val rank: String,
    val minXP: Int,
    val maxXP: Int
)