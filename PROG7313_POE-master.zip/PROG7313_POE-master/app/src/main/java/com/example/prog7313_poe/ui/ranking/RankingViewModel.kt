package com.example.prog7313_poe.ui.ranking

import androidx.lifecycle.ViewModel

class RankingViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}