package com.example.prog7313_poe.ui.loginRegister

import androidx.fragment.app.Fragment

class LoginFragment : Fragment() {
    // TODO: Use the ViewModel
}