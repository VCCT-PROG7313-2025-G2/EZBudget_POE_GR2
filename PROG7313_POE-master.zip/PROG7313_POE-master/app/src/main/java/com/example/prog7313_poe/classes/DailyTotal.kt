package com.example.prog7313_poe.classes
import java.util.Date

data class DailyTotal(
    val date: Date,
    val total: Double
)
