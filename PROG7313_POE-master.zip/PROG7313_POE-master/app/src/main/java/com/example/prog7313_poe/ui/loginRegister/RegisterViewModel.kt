package com.example.prog7313_poe.ui.loginRegister

import androidx.lifecycle.ViewModel

class RegisterViewModel (

): ViewModel(){
    // TODO: Implement the ViewModel
}